package ru.sber.cargotech.ai.rag;

import org.springframework.stereotype.Service;
import ru.sber.cargotech.ai.claim.dto.GenerateClaimRequest;
import ru.sber.cargotech.ai.gigachat.GigaChatEmbeddingClient;
import ru.sber.cargotech.ai.qdrant.QdrantRestClient;
import ru.sber.cargotech.ai.rag.dto.PaymentDelayRagContextRequest;
import ru.sber.cargotech.ai.rag.dto.PaymentDelayRagContextResponse;
import ru.sber.cargotech.ai.rag.dto.SearchRagChunksRequest;
import ru.sber.cargotech.ai.rag.dto.SearchRagChunksResponse;

import java.time.Instant;
import java.util.*;

@Service
public class RagSearchService {

    private static final int DEFAULT_LIMIT = 5;
    private static final int MAX_LIMIT = 20;

    private final GigaChatEmbeddingClient embeddingClient;
    private final QdrantRestClient qdrantRestClient;

    public RagSearchService(
            GigaChatEmbeddingClient embeddingClient,
            QdrantRestClient qdrantRestClient
    ) {
        this.embeddingClient = embeddingClient;
        this.qdrantRestClient = qdrantRestClient;
    }

    public SearchRagChunksResponse searchRequest(SearchRagChunksRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Search request is null");
        }

        int limit = normalizeLimit(request.limit());
        double minScore = request.minScore() == null ? 0.0 : request.minScore();

        List<RagSearchHit> hits = search(
                request.query(),
                request.filters() == null ? Map.of() : request.filters(),
                limit
        );

        List<RagSearchHit> filteredHits = hits.stream()
                .filter(hit -> hit.score() == null || hit.score() >= minScore)
                .toList();

        List<String> warnings = new ArrayList<>();

        if (filteredHits.isEmpty()) {
            warnings.add("RAG search returned no chunks");
        }

        return new SearchRagChunksResponse(
                true,
                request.query(),
                request.filters() == null ? Map.of() : request.filters(),
                limit,
                minScore,
                filteredHits.size(),
                filteredHits,
                warnings,
                Instant.now()
        );
    }

    public List<RagSearchHit> search(String query, Map<String, Object> filters, int limit) {
        if (query == null || query.isBlank()) {
            throw new IllegalArgumentException("RAG query is blank");
        }

        int normalizedLimit = normalizeLimit(limit);

        List<Double> vector = embeddingClient.embedOne(query);
        Object raw = qdrantRestClient.queryPoints(vector, filters, normalizedLimit);

        return parseHits(raw);
    }

    public PaymentDelayRagContextResponse retrievePaymentDelayContextRequest(PaymentDelayRagContextRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("PaymentDelayRagContextRequest is null");
        }

        if (request.contractId() == null || request.contractId().isBlank()) {
            throw new IllegalArgumentException("contract_id is required");
        }

        PaymentDelayRagContext context = retrievePaymentDelayContext(request.contractId(), request.clientId());

        return new PaymentDelayRagContextResponse(
                true,
                request.contractId(),
                request.clientId(),
                context,
                Instant.now()
        );
    }

    public PaymentDelayRagContext retrievePaymentDelayContext(String contractId, String clientId) {
        if (contractId == null || contractId.isBlank()) {
            throw new IllegalArgumentException("contractId is required");
        }

        List<RagSearchHit> contractHits = new ArrayList<>();

        contractHits.addAll(search(
                "срок оплаты оказанных услуг дата подписания акта полный пакет документов",
                filters(
                        "rag_collection", RagCollection.CONTRACT_CONTEXT.name(),
                        "claim_type", "PAYMENT_DELAY",
                        "contract_id", contractId,
                        "chunk_type", RagChunkType.PAYMENT_TERM.name(),
                        "is_current", true
                ),
                2
        ));

        contractHits.addAll(search(
                "неустойка пени штраф просрочка оплаты процент за каждый день",
                filters(
                        "rag_collection", RagCollection.CONTRACT_CONTEXT.name(),
                        "claim_type", "PAYMENT_DELAY",
                        "contract_id", contractId,
                        "chunk_type", RagChunkType.CONTRACT_PENALTY.name(),
                        "is_current", true
                ),
                2
        ));

        contractHits.addAll(search(
                "претензионный порядок срок ответа на претензию мотивированный ответ",
                filters(
                        "rag_collection", RagCollection.CONTRACT_CONTEXT.name(),
                        "claim_type", "PAYMENT_DELAY",
                        "contract_id", contractId,
                        "chunk_type", RagChunkType.PRETRIAL_ORDER.name(),
                        "is_current", true
                ),
                2
        ));

        List<RagSearchHit> legalHits = search(
                "ГК РФ надлежащее исполнение обязательств срок оплаты договорная неустойка",
                filters(
                        "rag_collection", RagCollection.LEGAL_CONTEXT.name(),
                        "claim_type", "PAYMENT_DELAY",
                        "is_current", true
                ),
                4
        );

        List<RagSearchHit> templateHits = search(
                "шаблон претензии о просрочке оплаты структура реквизиты договор расчет требование приложения",
                filters(
                        "rag_collection", RagCollection.TEMPLATE_CONTEXT.name(),
                        "claim_type", "PAYMENT_DELAY",
                        "is_current", true
                ),
                1
        );

        List<RagSearchHit> exampleHits = search(
                "похожая претензия просрочка оплаты структура стиль сумма долга неустойка требование",
                filters(
                        "rag_collection", RagCollection.SIMILAR_EXAMPLE.name(),
                        "claim_type", "PAYMENT_DELAY",
                        "is_current", true
                ),
                1
        );

        return toPaymentDelayContext(contractHits, legalHits, templateHits, exampleHits);
    }

    private PaymentDelayRagContext toPaymentDelayContext(
            List<RagSearchHit> contractHits,
            List<RagSearchHit> legalHits,
            List<RagSearchHit> templateHits,
            List<RagSearchHit> exampleHits
    ) {
        List<GenerateClaimRequest.ContractContextChunk> contractContext = contractHits.stream()
                .map(RagSearchHit::chunk)
                .filter(Objects::nonNull)
                .map(chunk -> new GenerateClaimRequest.ContractContextChunk(
                        chunk.chunkId(),
                        chunk.clauseNumber(),
                        chunk.sectionTitle(),
                        chunk.text()
                ))
                .distinct()
                .toList();

        List<GenerateClaimRequest.LegalContextItem> legalContext = legalHits.stream()
                .map(RagSearchHit::chunk)
                .filter(Objects::nonNull)
                .map(chunk -> new GenerateClaimRequest.LegalContextItem(
                        str(chunk.extra().get("law_code")),
                        str(chunk.extra().get("article")),
                        str(chunk.extra().get("purpose"))
                ))
                .distinct()
                .toList();

        GenerateClaimRequest.TemplateContext templateContext = templateHits.stream()
                .findFirst()
                .map(RagSearchHit::chunk)
                .filter(Objects::nonNull)
                .map(chunk -> new GenerateClaimRequest.TemplateContext(
                        str(chunk.extra().get("template_id")),
                        str(chunk.extra().get("template_name")),
                        GenerateClaimRequest.ClaimType.PAYMENT_DELAY,
                        toStringList(chunk.extra().get("template_structure"))
                ))
                .orElse(null);

        List<GenerateClaimRequest.SimilarExample> similarExamples = exampleHits.stream()
                .map(RagSearchHit::chunk)
                .filter(Objects::nonNull)
                .map(chunk -> new GenerateClaimRequest.SimilarExample(
                        str(chunk.extra().get("example_id")),
                        GenerateClaimRequest.ClaimType.PAYMENT_DELAY,
                        str(chunk.extra().get("usage_rule")),
                        str(chunk.extra().get("structure_summary"))
                ))
                .distinct()
                .toList();

        List<String> warnings = new ArrayList<>();

        if (contractContext.isEmpty()) {
            warnings.add("contract_context is empty");
        }

        if (legalContext.isEmpty()) {
            warnings.add("legal_context is empty");
        }

        if (templateContext == null) {
            warnings.add("template_context is empty");
        }

        return new PaymentDelayRagContext(
                contractContext,
                legalContext,
                templateContext,
                similarExamples,
                warnings
        );
    }

    @SuppressWarnings("unchecked")
    private List<RagSearchHit> parseHits(Object raw) {
        if (!(raw instanceof Map<?, ?> rawMap)) {
            return List.of();
        }

        Object result = rawMap.get("result");

        List<?> points;

        if (result instanceof Map<?, ?> resultMap && resultMap.get("points") instanceof List<?> list) {
            points = list;
        } else if (result instanceof List<?> list) {
            points = list;
        } else {
            return List.of();
        }

        List<RagSearchHit> hits = new ArrayList<>();

        for (Object item : points) {
            if (!(item instanceof Map<?, ?> point)) {
                continue;
            }

            Object payloadObject = point.get("payload");

            if (!(payloadObject instanceof Map<?, ?> payloadRaw)) {
                continue;
            }

            Map<String, Object> payload = new LinkedHashMap<>();

            for (Map.Entry<?, ?> entry : payloadRaw.entrySet()) {
                payload.put(String.valueOf(entry.getKey()), entry.getValue());
            }

            RagChunk chunk = RagChunk.fromPayload(payload);

            hits.add(new RagSearchHit(
                    str(point.get("id")),
                    doubleValue(point.get("score")),
                    chunk
            ));
        }

        return hits;
    }

    private int normalizeLimit(Integer limit) {
        if (limit == null) {
            return DEFAULT_LIMIT;
        }

        if (limit <= 0) {
            throw new IllegalArgumentException("RAG limit must be positive");
        }

        return Math.min(limit, MAX_LIMIT);
    }

    private Map<String, Object> filters(Object... args) {
        if (args.length % 2 != 0) {
            throw new IllegalArgumentException("Filters args must be key-value pairs");
        }

        Map<String, Object> filters = new LinkedHashMap<>();

        for (int i = 0; i < args.length; i += 2) {
            filters.put(String.valueOf(args[i]), args[i + 1]);
        }

        return filters;
    }

    private static String str(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private static Double doubleValue(Object value) {
        if (value == null) {
            return null;
        }

        if (value instanceof Number number) {
            return number.doubleValue();
        }

        return Double.parseDouble(String.valueOf(value));
    }

    private static List<String> toStringList(Object value) {
        if (value == null) {
            return List.of();
        }

        if (value instanceof List<?> list) {
            return list.stream()
                    .map(String::valueOf)
                    .toList();
        }

        return List.of(String.valueOf(value));
    }

    public record PaymentDelayRagContext(
            List<GenerateClaimRequest.ContractContextChunk> contractContext,
            List<GenerateClaimRequest.LegalContextItem> legalContext,
            GenerateClaimRequest.TemplateContext templateContext,
            List<GenerateClaimRequest.SimilarExample> similarExamples,
            List<String> warnings
    ) {
    }
}